from django.shortcuts import render
def index(request):
    if request.method=="POST":
        n = int(request.POST.get("num"))
        f=1
        for i in range(1,n+1):
            f=f*i
        return render(request,"factapp/factorial.html",{"key":"result is "+str(f)})
    else:
        return render(request,"factapp/factorial.html")

def table(request):
    if request.method=="POST":
        num = int(request.POST.get("txtnum"))
        lst=[]
        if request.POST.get("btnsubmit1")!=None:
           for i in range(1,11):
                lst.append(num*i)
        else:
            for i in range(11,1,-1):
                lst.append(num*i)
        return render(request,"factapp/table.html",{"key":lst})

    else:
        return render(request,"factapp/table.html")
def squarecube(request):
    if request.method=="POST":
        num = int(request.POST.get("txtnum"))
        result=''
        if request.POST.get("btnsquare")!=None:
            result = num*num
        else:
            result = num*num*num
        return render(request,"factapp/square_cube.html",{"data1":num,"key":result})

    else:
        return render(request,"factapp/square_cube.html")