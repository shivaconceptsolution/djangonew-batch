from django.shortcuts import render
def index(request):
    if request.method=="POST":
        n = int(request.POST.get("num"))
        f=1
        for i in range(1,n+1):
            f=f*i
        return render(request,"factapp/factorial.html",{"key":"result is "+str(f)})
    else:
        return render(request,"factapp/factorial.html")

def table(request):
    if request.method=="POST":
        num = int(request.POST.get("txtnum"))
        lst=[]
        for i in range(1,11):
            lst.append(num*i)
        return render(request,"factapp/table.html",{"key":lst})

    else:
        return render(request,"factapp/table.html")