from django.http import HttpResponse
from django.shortcuts import render
def index(request):
    return render(request,"helloapp/hello.html")
def addition(request):
    if request.method=="POST":
       a,b=request.POST.get("txtnum1"),request.POST.get("txtnum2")
       c=int(a)+int(b)
       return render(request,"helloapp/addition.html",{"key":"result is "+str(c)})
    else:
        return render(request,"helloapp/addition.html")
    
def sicalc(request):
    if request.method=="POST":
       p,r,t = request.POST.get("txtnum1"),request.POST.get("txtnum2"),request.POST.get("txtnum3")
       si = (float(p)*float(r)*float(t))/100
       return render(request,"helloapp/si.html",{"key":"result is "+str(si)})
    else:
        return render(request,"helloapp/si.html")

