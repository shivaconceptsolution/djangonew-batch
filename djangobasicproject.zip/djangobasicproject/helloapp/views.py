from django.http import HttpResponse
def index(request):
    return HttpResponse("Hello world")
def addition(request):
    a,b=10,2
    c=a+b
    print(c)
    return HttpResponse("addition is "+str(c))
def sicalc(request):
    p,r,t = 120000,2,2
    si = (p*r*t)/100
    return HttpResponse("result is "+str(si))

