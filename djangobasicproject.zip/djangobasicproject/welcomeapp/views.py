from django.http import HttpResponse
def index(request):
    return HttpResponse('welcome in second app')

def swap(request):
    a,b=10,20
    a,b=b,a
    return HttpResponse("a={0} and b={1}".format(a,b))