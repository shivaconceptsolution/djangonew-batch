from django.shortcuts import render
def home(request):
    return render(request,"secuityapp/index.html")
def aboutus(request):
    return render(request,"secuityapp/about.html")
def services(request):
    return render(request,"secuityapp/service.html")
def contactus(request):
    return render(request,"secuityapp/contact.html")
def guards(request):
    return render(request,"secuityapp/guard.html")